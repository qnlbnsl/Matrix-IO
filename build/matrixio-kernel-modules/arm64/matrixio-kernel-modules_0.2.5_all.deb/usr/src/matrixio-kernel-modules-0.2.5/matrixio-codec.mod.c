#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xcb66bd37, "__platform_driver_register" },
	{ 0x46afa0be, "devm_snd_soc_register_component" },
	{ 0xc1084bd7, "devm_snd_soc_register_card" },
	{ 0x8c815836, "_dev_err" },
	{ 0x9fd0e8df, "platform_driver_unregister" },
	{ 0xb1417203, "snd_soc_pm_ops" },
	{ 0xe3035aa9, "module_layout" },
};

MODULE_INFO(depends, "snd-soc-core");

MODULE_ALIAS("of:N*T*Cmatrixio-codec");
MODULE_ALIAS("of:N*T*Cmatrixio-codecC*");

MODULE_INFO(srcversion, "0ACB8D2BEA30D27F22F650D");
