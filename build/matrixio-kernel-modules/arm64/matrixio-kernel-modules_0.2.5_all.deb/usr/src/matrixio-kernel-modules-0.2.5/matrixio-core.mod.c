#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

SYMBOL_CRC(matrixio_read, 0x2f7f73f5, "");
SYMBOL_CRC(matrixio_write, 0xc2e69898, "");
SYMBOL_CRC(matrixio_reg_write, 0xaf2bf496, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xfdb29ab1, "__spi_register_driver" },
	{ 0xdcb764ad, "memset" },
	{ 0x7deddc72, "devm_mfd_add_devices" },
	{ 0x8da6585d, "__stack_chk_fail" },
	{ 0xaf207543, "driver_unregister" },
	{ 0xccf0bfc7, "spi_setup" },
	{ 0xd4d0cbf1, "devm_kmalloc" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xee67da14, "__devm_regmap_init" },
	{ 0x8c815836, "_dev_err" },
	{ 0xee5997c7, "spi_sync" },
	{ 0x4829a47e, "memcpy" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xe3035aa9, "module_layout" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("of:N*T*Cmatrixio-core");
MODULE_ALIAS("of:N*T*Cmatrixio-coreC*");

MODULE_INFO(srcversion, "DF5C0B5D4E4F9D7E01DFB3E");
