#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xcb66bd37, "__platform_driver_register" },
	{ 0x54d8c63d, "uart_remove_one_port" },
	{ 0xc9003717, "uart_unregister_driver" },
	{ 0x8d2cded0, "uart_register_driver" },
	{ 0x73888d75, "irq_of_parse_and_map" },
	{ 0xcac5c4c, "uart_add_one_port" },
	{ 0x8c815836, "_dev_err" },
	{ 0x9166fc03, "__flush_workqueue" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0xc1514a3b, "free_irq" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x2f7f73f5, "matrixio_read" },
	{ 0xaf2bf496, "matrixio_reg_write" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x8da6585d, "__stack_chk_fail" },
	{ 0x49cd25ed, "alloc_workqueue" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x5e77583b, "_dev_info" },
	{ 0x9fd0e8df, "platform_driver_unregister" },
	{ 0xd73653c4, "freezer_active" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x35e30271, "freezing_slow_path" },
	{ 0x8427cc7b, "_raw_spin_lock_irq" },
	{ 0x4b750f53, "_raw_spin_unlock_irq" },
	{ 0xbd64ac3e, "__tty_insert_flip_char" },
	{ 0x9a3952d3, "tty_flip_buffer_push" },
	{ 0xe3035aa9, "module_layout" },
};

MODULE_INFO(depends, "matrixio-core");

MODULE_ALIAS("of:N*T*Cmatrixio-uart");
MODULE_ALIAS("of:N*T*Cmatrixio-uartC*");

MODULE_INFO(srcversion, "C6712BAB25B1B52297927E2");
