#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xcb66bd37, "__platform_driver_register" },
	{ 0x8c27255f, "iio_device_unregister" },
	{ 0x3bdc3f49, "devm_iio_device_alloc" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x55d9641, "__iio_device_register" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x2f7f73f5, "matrixio_read" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x8da6585d, "__stack_chk_fail" },
	{ 0x9fd0e8df, "platform_driver_unregister" },
	{ 0xe3035aa9, "module_layout" },
};

MODULE_INFO(depends, "industrialio,matrixio-core");


MODULE_INFO(srcversion, "AD74BF763F07C4E86D64244");
